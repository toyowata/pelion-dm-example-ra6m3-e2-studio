The mbed Device C Client Library provides a simple and efficient way to create mbed Device Client in 
C.

Applications not using mbed-coap via mbedOS should add mbed-coap library either via mbed-coap.lib or via other
applicable means.
